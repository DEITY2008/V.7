# THEP 4WD — โปรเจ็คเด็กคอม

แอปบังคับรถ 4WD ผ่าน Bluetooth (ESP32) มีหน้าขับ + สั่งเสียงภาษาไทย

## ได้ไฟล์ APK
1. Push โปรเจกต์ขึ้น GitHub (branch `main`)
2. แท็บ **Actions** → workflow **Build APK** → รอรันเสร็จ (~3-5 นาที)
3. เลื่อนลงล่าง **Artifacts** → ดาวน์โหลด `THEP-4WD-apk` (แตก zip จะได้ `app-debug.apk`)

กดรันเองได้ที่ Actions → Build APK → Run workflow
