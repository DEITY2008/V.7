package com.thep.controller

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import java.io.InputStream
import java.util.UUID
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.math.*

private const val BG = 0xFF07080C.toInt()
private const val PANEL = 0xFF151A21.toInt()
private const val LINE = 0xFF2A323D.toInt()
private const val AMBER = 0xFFFFB300.toInt()
private const val ORG = 0xFFFF6A00.toInt()
private const val YEL = 0xFFFFE066.toInt()
private const val CYAN = 0xFF22D3EE.toInt()
private const val RED = 0xFFFF3B30.toInt()
private const val GREEN = 0xFF34D399.toInt()
private const val TXT = 0xFFE6EDF3.toInt()
private const val DIM = 0xFF7B8794.toInt()
private const val PIF = 3.14159265f
private const val TITLE = "โปรเจ็คเด็กคอม"

private fun rnd() = Math.random().toFloat()

// ============================================================ เอฟเฟกต์ประกายไฟ
class Sparks(private val cap: Int = 220) {
    private val x = FloatArray(cap); private val y = FloatArray(cap)
    private val vx = FloatArray(cap); private val vy = FloatArray(cap)
    private val life = FloatArray(cap); private val ml = FloatArray(cap); private val sz = FloatArray(cap)
    private var i = 0
    private val cols = intArrayOf(0xFFFFF0A0.toInt(), 0xFFFFB300.toInt(), 0xFFFF6A00.toInt(), 0xFFFF3B30.toInt())

    fun emit(px: Float, py: Float, n: Int, speed: Float, ang: Float, spread: Float, size: Float) {
        repeat(n) {
            val a = ang + (rnd() - 0.5f) * spread
            val s = speed * (0.4f + rnd() * 0.8f)
            x[i] = px; y[i] = py; vx[i] = cos(a) * s; vy[i] = sin(a) * s
            ml[i] = 0.4f + rnd() * 0.7f; life[i] = ml[i]; sz[i] = size * (0.5f + rnd())
            i = (i + 1) % cap
        }
    }

    fun draw(c: Canvas, dt: Float, p: Paint, grav: Float) {
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.shader = null
        for (k in 0 until cap) {
            if (life[k] <= 0f) continue
            life[k] -= dt; if (life[k] <= 0f) continue
            vy[k] += grav * dt
            x[k] += vx[k] * dt; y[k] += vy[k] * dt
            val f = life[k] / ml[k]
            p.color = cols[min(3, ((1f - f) * 4f).toInt())]
            p.alpha = (f * 255).toInt(); p.strokeWidth = sz[k] * (0.4f + f)
            c.drawLine(x[k] - vx[k] * 0.045f, y[k] - vy[k] * 0.045f, x[k], y[k], p)
        }
        p.alpha = 255; p.strokeCap = Paint.Cap.BUTT
    }
}

// ============================================================ พื้นหลังเรืองแสง
class Backdrop(private val w: Float, private val h: Float, private val d: Float) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = RadialGradient(w * 0.5f, h * 1.15f, max(w, h) * 0.8f, intArrayOf(0xFFC0180A.toInt(), 0x00000000), null, Shader.TileMode.CLAMP)
    private val vig = RadialGradient(w / 2, h / 2, max(w, h) * 0.72f, intArrayOf(0x00000000, 0xE0000000.toInt()), floatArrayOf(0.45f, 1f), Shader.TileMode.CLAMP)
    fun draw(c: Canvas, t: Float, heat: Float) {
        c.drawColor(BG)
        p.style = Paint.Style.FILL; p.color = 0xFFFFFFFF.toInt(); p.shader = glow; p.alpha = (60 + heat * 150).toInt()
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f * d; p.color = 0x1CFF6A00
        val gap = 46 * d; val off = (t * 38 * d * (1f + heat * 3f)) % gap
        var x = -h + off
        while (x < w) { c.drawLine(x, h, x + h, 0f, p); x += gap }
        p.style = Paint.Style.FILL; p.color = 0xFFFFFFFF.toInt(); p.shader = vig; p.alpha = 255
        c.drawRect(0f, 0f, w, h, p); p.shader = null
    }
}

// ============================================================ เครื่องมือวาด (นีออน / รถ / เกจ)
class Gfx(val d: Float) {
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD }
    private val path = Path(); private val rr = RectF()

    fun mix(a: Int, b: Int, f: Float): Int {
        val k = f.coerceIn(0f, 1f)
        return Color.argb(255, (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt())
    }

    fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, align: Paint.Align = Paint.Align.CENTER, spacing: Float = 0f) {
        tp.style = Paint.Style.FILL; tp.shader = null; tp.textSize = size; tp.color = color
        tp.textAlign = align; tp.letterSpacing = spacing
        c.drawText(s, x, y + size * 0.35f, tp)
    }

    fun glowTxt(c: Canvas, s: String, x: Float, y: Float, size: Float, fill: Int, glow: Int) {
        tp.textSize = size; tp.textAlign = Paint.Align.CENTER; tp.shader = null; tp.letterSpacing = 0f
        tp.strokeJoin = Paint.Join.ROUND; tp.style = Paint.Style.STROKE
        tp.color = glow; tp.strokeWidth = size * 0.22f; tp.alpha = 40; c.drawText(s, x, y + size * 0.35f, tp)
        tp.strokeWidth = size * 0.10f; tp.alpha = 90; c.drawText(s, x, y + size * 0.35f, tp)
        tp.style = Paint.Style.FILL; tp.color = fill; c.drawText(s, x, y + size * 0.35f, tp)
    }

    fun glowPath(c: Canvas, pa: Path, color: Int, w: Float) {
        p.style = Paint.Style.STROKE; p.shader = null; p.strokeJoin = Paint.Join.ROUND; p.strokeCap = Paint.Cap.ROUND
        p.color = color
        p.strokeWidth = w * 5f; p.alpha = 28; c.drawPath(pa, p)
        p.strokeWidth = w * 2.6f; p.alpha = 70; c.drawPath(pa, p)
        p.strokeWidth = w; p.alpha = 255; c.drawPath(pa, p)
        p.strokeCap = Paint.Cap.BUTT
    }

    fun glowRR(c: Canvas, r: RectF, rad: Float, color: Int, w: Float) {
        path.reset(); path.addRoundRect(r, rad, rad, Path.Direction.CW); glowPath(c, path, color, w)
    }

    fun glowLine(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, color: Int, w: Float) {
        path.reset(); path.moveTo(x1, y1); path.lineTo(x2, y2); glowPath(c, path, color, w)
    }

    fun chevH(c: Canvas, x: Float, y: Float, dir: Int, s: Float, color: Int) {
        path.reset(); path.moveTo(x - dir * s * 0.5f, y - s); path.lineTo(x + dir * s * 0.5f, y); path.lineTo(x - dir * s * 0.5f, y + s)
        glowPath(c, path, color, 2f * d)
    }

    fun chevV(c: Canvas, x: Float, y: Float, dir: Int, s: Float, color: Int) {
        path.reset(); path.moveTo(x - s, y - dir * s * 0.5f); path.lineTo(x, y + dir * s * 0.5f); path.lineTo(x + s, y - dir * s * 0.5f)
        glowPath(c, path, color, 2f * d)
    }

    fun chip(c: Canvas, r: RectF, label: String, color: Int, on: Boolean, size: Float) {
        val rad = 10 * d
        p.style = Paint.Style.FILL; p.shader = null; p.color = if (on) color else 0xCC151A21.toInt()
        c.drawRoundRect(r, rad, rad, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.6f * d; p.color = color; if (!on) p.alpha = 210
        c.drawRoundRect(r, rad, rad, p); p.alpha = 255
        txt(c, label, r.centerX(), r.centerY(), size, if (on) BG else color)
    }

    // ป้ายสถานะเชื่อมต่อ (มุมซ้ายบน)
    fun pill(c: Canvas, r: RectF, on: Boolean, name: String, t: Float) {
        val col = if (on) GREEN else RED
        val rad = r.height() / 2
        p.style = Paint.Style.FILL; p.shader = null; p.color = 0xDD0A0C10.toInt(); c.drawRoundRect(r, rad, rad, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.6f * d; p.color = col
        p.alpha = if (on) 255 else (130 + 125 * abs(sin(t * 5f))).toInt()
        c.drawRoundRect(r, rad, rad, p); p.alpha = 255
        val cy = r.centerY(); val dx = r.left + r.height() * 0.5f
        p.style = Paint.Style.FILL; p.color = col; p.alpha = 70
        c.drawCircle(dx, cy, r.height() * 0.33f * (1f + 0.3f * sin(t * 4f)), p)
        p.color = col; p.alpha = if (on) 255 else (110 + 145 * abs(sin(t * 5f))).toInt()
        c.drawCircle(dx, cy, r.height() * 0.16f, p); p.alpha = 255
        txt(c, if (on) "เชื่อมต่อแล้ว" else "ไม่ได้เชื่อมต่อ", dx + r.height() * 0.45f, cy, r.height() * 0.40f, col, Paint.Align.LEFT)
        if (on && name.isNotEmpty()) txt(c, name.take(10), r.right - r.height() * 0.4f, cy, r.height() * 0.30f, DIM, Paint.Align.RIGHT)
    }

    // ---------------- รถ 4WD ด้านข้าง ----------------
    private val body = Path().apply {
        moveTo(-195f, 38f); lineTo(-198f, 4f); lineTo(-170f, -10f); lineTo(-118f, -16f)
        cubicTo(-100f, -20f, -85f, -56f, -50f, -62f); lineTo(10f, -62f)
        cubicTo(40f, -60f, 62f, -36f, 90f, -22f); lineTo(168f, -8f)
        cubicTo(188f, -4f, 198f, 8f, 198f, 24f); lineTo(194f, 38f); close()
    }
    private val glass = Path().apply { moveTo(-82f, -24f); lineTo(-48f, -55f); lineTo(6f, -55f); lineTo(50f, -24f); close() }
    private val lamp = Path().apply { moveTo(166f, -6f); lineTo(194f, 8f); lineTo(190f, 17f); lineTo(165f, 5f); close() }
    private val wing = Path().apply { moveTo(-208f, -44f); lineTo(-146f, -44f); moveTo(-188f, -44f); lineTo(-184f, -12f); moveTo(-166f, -44f); lineTo(-168f, -14f) }
    private val beam = Path().apply { moveTo(196f, 10f); lineTo(420f, -45f); lineTo(420f, 75f); close() }
    private val flame = Path(); private val spokes = Path()
    private val bodyFill = LinearGradient(0f, -62f, 0f, 40f, intArrayOf(0xFFFF4A1F.toInt(), 0xFF9A1008.toInt(), 0xFF1A0504.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
    private val glassFill = LinearGradient(0f, -55f, 0f, -24f, 0xDD7DF3FF.toInt(), 0xDD0B3A55.toInt(), Shader.TileMode.CLAMP)
    private val beamFill = LinearGradient(196f, 0f, 420f, 0f, 0x99FFEFB0.toInt(), 0x00FFEFB0, Shader.TileMode.CLAMP)

    private fun wheel(c: Canvas, x: Float, y: Float, r: Float, ang: Float) {
        p.style = Paint.Style.FILL; p.shader = null; p.color = 0xFF0C0E12.toInt(); c.drawCircle(x, y, r, p)
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.BUTT; p.color = 0xFF3A424D.toInt(); p.strokeWidth = 7f
        for (i in 0 until 16) {
            val a = ang + i * (2f * PIF / 16f)
            c.drawLine(x + cos(a) * (r - 9f), y + sin(a) * (r - 9f), x + cos(a) * (r + 1f), y + sin(a) * (r + 1f), p)
        }
        path.reset(); path.addCircle(x, y, r * 0.62f, Path.Direction.CW); glowPath(c, path, ORG, 3.5f)
        spokes.reset()
        for (i in 0 until 5) {
            val a = ang * 1.0f + i * (2f * PIF / 5f)
            spokes.moveTo(x, y); spokes.lineTo(x + cos(a) * r * 0.6f, y + sin(a) * r * 0.6f)
        }
        glowPath(c, spokes, YEL, 2.5f)
        p.style = Paint.Style.FILL; p.color = YEL; c.drawCircle(x, y, r * 0.13f, p)
    }

    /** วาดรถ หันไปทางขวา; ang = มุมหมุนล้อ, heat = ความแรงของไฟท่อ 0..1 */
    fun car(c: Canvas, cx: Float, cy: Float, s: Float, t: Float, ang: Float, heat: Float) {
        c.save(); c.translate(cx, cy); c.scale(s, s)
        p.shader = null; p.style = Paint.Style.FILL
        p.color = RED; p.alpha = 34; rr.set(-260f, 78f, 260f, 114f); c.drawOval(rr, p)
        p.color = ORG; p.alpha = 70; rr.set(-200f, 84f, 200f, 108f); c.drawOval(rr, p)
        p.color = YEL; p.alpha = 110; rr.set(-130f, 88f, 130f, 100f); c.drawOval(rr, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.strokeCap = Paint.Cap.ROUND
        for (k in 0..5) {
            val y = -44f + k * 27f
            val off = (t * (520f + k * 70f) + k * 97f) % 300f
            p.color = ORG; p.alpha = (110 - off / 300f * 100f).toInt().coerceIn(0, 255)
            c.drawLine(-215f - off, y, -285f - off, y, p)
        }
        p.strokeCap = Paint.Cap.BUTT
        p.style = Paint.Style.FILL; p.color = 0xFFFFFFFF.toInt(); p.shader = beamFill; c.drawPath(beam, p); p.shader = null
        val len = 34f + heat * 80f + sin(t * 55f) * 10f
        flame.reset(); flame.moveTo(-196f, 12f); flame.lineTo(-196f - len, 22f + sin(t * 41f) * 5f); flame.lineTo(-196f, 32f); flame.close()
        p.color = ORG; p.alpha = 230; c.drawPath(flame, p)
        flame.reset(); flame.moveTo(-196f, 17f); flame.lineTo(-196f - len * 0.55f, 22f); flame.lineTo(-196f, 27f); flame.close()
        p.color = YEL; c.drawPath(flame, p)
        p.color = 0xFFFFFFFF.toInt(); p.shader = bodyFill; c.drawPath(body, p); p.shader = null
        glowPath(c, body, ORG, 2.5f)
        p.style = Paint.Style.FILL; p.color = 0xFFFFFFFF.toInt(); p.shader = glassFill; c.drawPath(glass, p); p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = CYAN; c.drawPath(glass, p)
        glowLine(c, -188f, 12f, 190f, 14f, YEL, 2.5f)
        p.style = Paint.Style.FILL; p.color = 0xFFFFF4C0.toInt(); c.drawPath(lamp, p)
        p.color = YEL; p.alpha = 70; c.drawCircle(190f, 10f, 16f, p)
        p.color = RED; rr.set(-200f, -2f, -192f, 14f); c.drawRect(rr, p)
        p.color = 0xFF05070A.toInt(); c.drawCircle(-122f, 44f, 51f, p); c.drawCircle(126f, 44f, 51f, p)
        wheel(c, -122f, 44f, 46f, ang); wheel(c, 126f, 44f, 46f, ang)
        glowPath(c, wing, CYAN, 3f)
        c.restore()
    }
}

// ============================================================ หน้าแรก (พื้นหลัง + ชื่อ + รถ)
@SuppressLint("ViewConstructor")
class HomeView(ctx: Context) : View(ctx) {
    var online: () -> Boolean = { false }
    var deviceName = ""
    private val d = resources.displayMetrics.density
    private val g = Gfx(d); private val sp = Sparks()
    private val tt = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC) }
    private var bd: Backdrop? = null
    private var t = 0f; private var last = 0L
    private val pillR = RectF()
    private var tSize = 0f; private var tY = 0f; private var tW = 0f; private var tShader: Shader? = null
    private val loop = object : Runnable { override fun run() { invalidate(); postOnAnimation(this) } }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); last = System.nanoTime(); postOnAnimation(loop) }
    override fun onDetachedFromWindow() { removeCallbacks(loop); super.onDetachedFromWindow() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        bd = Backdrop(w.toFloat(), h.toFloat(), d)
        pillR.set(16 * d, 12 * d, 16 * d + 196 * d, 12 * d + 30 * d)
        tSize = h * 0.12f; tt.textSize = tSize
        val wd = tt.measureText(TITLE)
        if (wd > w * 0.44f) { tSize *= w * 0.44f / wd; tt.textSize = tSize }
        tW = tt.measureText(TITLE)
        tY = pillR.bottom + tSize * 1.25f
        tShader = LinearGradient(0f, tY - tSize, 0f, tY, intArrayOf(0xFFFFF6C8.toInt(), 0xFFFFB300.toInt(), 0xFFFF3B1A.toInt()), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val now = System.nanoTime(); val dt = min(0.05f, (now - last) / 1e9f); last = now; t += dt
        bd?.draw(c, t, 0.35f)
        // ชื่อโปรเจ็ค
        val x = 18 * d
        tt.shader = null; tt.strokeJoin = Paint.Join.ROUND; tt.style = Paint.Style.STROKE; tt.color = ORG
        tt.strokeWidth = tSize * 0.20f; tt.alpha = 35; c.drawText(TITLE, x, tY, tt)
        tt.strokeWidth = tSize * 0.09f; tt.alpha = 90; c.drawText(TITLE, x, tY, tt)
        tt.style = Paint.Style.FILL; tt.shader = tShader; tt.alpha = 255; c.drawText(TITLE, x, tY, tt); tt.shader = null
        val uy = tY + 10 * d
        g.glowLine(c, x, uy, x + tW, uy, ORG, 2.5f * d)
        val a = x + ((t * 0.6f) % 1f) * tW
        g.glowLine(c, a, uy, min(a + 46 * d, x + tW), uy, 0xFFFFFFFF.toInt(), 2.5f * d)
        g.txt(c, "THEP 4WD  •  RC CONTROLLER", x, uy + 20 * d, 11 * d, DIM, Paint.Align.LEFT, 0.25f)
        // รถ
        val s = w * 0.50f / 400f; val cx = w * 0.735f; val cy = h * 0.52f + sin(t * 2.2f) * 3 * d
        c.save(); c.rotate(-3f, cx, cy)
        g.car(c, cx, cy, s, t, t * 14f, 0.6f + 0.4f * sin(t * 3f))
        c.restore()
        // ประกายไฟ
        repeat(2) { sp.emit(cx - 198 * s, cy + 22 * s, 1, 620 * d, PIF, 0.7f, 2.4f * d) }
        sp.emit(cx - 122 * s, cy + 92 * s, 1, 520 * d, PIF + 0.4f, 0.8f, 2f * d)
        sp.emit(cx + 126 * s, cy + 92 * s, 1, 520 * d, PIF + 0.4f, 0.8f, 2f * d)
        if (rnd() < 0.35f) sp.emit(rnd() * w, h + 6 * d, 1, 520 * d, -PIF / 2, 0.5f, 2.2f * d)
        sp.draw(c, dt, g.p, 300 * d)
        g.pill(c, pillR, online(), deviceName, t)
    }
}

// ============================================================ หน้าขับ
@SuppressLint("ViewConstructor")
class DriveView(ctx: Context) : View(ctx) {
    @Volatile var outL = 0
    @Volatile var outR = 0
    @Volatile var linkOk = false
    var gear = 1
    var estop = false
    var invThr = false
    var invStr = false
    var deviceName = ""
    var online: () -> Boolean = { false }
    var onSetup: () -> Unit = {}
    var onDisconnect: () -> Unit = {}
    var onMic: () -> Unit = {}

    private var thr = 0f; private var str = 0f
    private var thrId = -1; private var strId = -1
    private var dispL = 0f; private var dispR = 0f
    private var last = 0L; private var t = 0f; private var fdt = 0.016f
    private val d = resources.displayMetrics.density
    private val g = Gfx(d); private val p = g.p
    private val sp = Sparks()
    private var bd: Backdrop? = null
    private val thrR = RectF(); private val strR = RectF(); private val estopR = RectF()
    private val setupR = RectF(); private val micR = RectF(); private val discR = RectF(); private val pillR = RectF()
    private val gearR = Array(3) { RectF() }
    private val gearName = arrayOf("ECO", "NORMAL", "TURBO")
    private val gearCap = floatArrayOf(0.55f, 0.8f, 1f)
    private val tmp = RectF(); private val arc = Path()
    private var gcx = 0f; private var gcy = 0f; private var gr = 0f
    private var fwd: Shader? = null; private var rev: Shader? = null

    private val loop = object : Runnable {
        override fun run() { step(); invalidate(); postOnAnimation(this) }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); last = System.nanoTime(); postOnAnimation(loop) }
    override fun onDetachedFromWindow() { removeCallbacks(loop); super.onDetachedFromWindow() }

    fun reset() { thr = 0f; str = 0f; thrId = -1; strId = -1 }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        bd = Backdrop(w.toFloat(), h.toFloat(), d)
        val m = h * 0.06f
        // สลับฝั่ง: คันเร่งอยู่ขวา, พวงมาลัยอยู่ซ้าย
        thrR.set(w - m - h * 0.30f, m, w - m, h - m)
        strR.set(m, h * 0.58f, m + w * 0.34f, h * 0.86f)
        pillR.set(m, m, m + 200 * d, m + 30 * d)
        val cw = (strR.width() - 12 * d) / 3f; val cy0 = pillR.bottom + 8 * d
        setupR.set(m, cy0, m + cw, cy0 + 30 * d)
        micR.set(m + cw + 6 * d, cy0, m + 2 * cw + 6 * d, cy0 + 30 * d)
        discR.set(m + 2 * cw + 12 * d, cy0, m + 3 * cw + 12 * d, cy0 + 30 * d)
        val zl = strR.right; val zr = thrR.left
        val cx = (zl + zr) / 2f; val gw = (zr - zl) * 0.27f
        for (i in 0..2) gearR[i].set(cx - gw * 1.5f - 6 * d + i * (gw + 6 * d), h * 0.06f, cx - gw * 1.5f - 6 * d + i * (gw + 6 * d) + gw, h * 0.16f)
        estopR.set(cx - gw * 1.3f, h * 0.80f, cx + gw * 1.3f, h - m)
        gcx = cx; gcy = h * 0.47f; gr = min(h * 0.28f, (zr - zl) * 0.30f)
        fwd = LinearGradient(0f, thrR.centerY(), 0f, thrR.top, intArrayOf(0xFF7A0A00.toInt(), RED, ORG, YEL), floatArrayOf(0f, 0.35f, 0.7f, 1f), Shader.TileMode.CLAMP)
        rev = LinearGradient(0f, thrR.centerY(), 0f, thrR.bottom, intArrayOf(0xFF0A2A66.toInt(), 0xFF0B5FFF.toInt(), CYAN), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
    }

    private fun hit(r: RectF, x: Float, y: Float, pad: Float = 0f) =
        x >= r.left - pad && x <= r.right + pad && y >= r.top - pad && y <= r.bottom + pad

    private fun setThr(y: Float) { thr = ((thrR.centerY() - y) / (thrR.height() / 2f - 10 * d)).coerceIn(-1f, 1f) }
    private fun setStr(x: Float) { str = ((x - strR.centerX()) / (strR.width() / 2f - 10 * d)).coerceIn(-1f, 1f) }
    private fun tap() { performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex; val id = e.getPointerId(i); val x = e.getX(i); val y = e.getY(i)
                when {
                    hit(estopR, x, y, 8 * d) -> { estop = !estop; tap() }
                    hit(setupR, x, y, 6 * d) -> { reset(); onSetup() }
                    hit(micR, x, y, 6 * d) -> { reset(); onMic() }
                    hit(discR, x, y, 6 * d) -> { reset(); onDisconnect() }
                    gearR.indexOfFirst { hit(it, x, y, 6 * d) } >= 0 -> { gear = gearR.indexOfFirst { hit(it, x, y, 6 * d) }; tap() }
                    hit(thrR, x, y, 24 * d) && thrId == -1 -> { thrId = id; setThr(y) }
                    hit(strR, x, y, 30 * d) && strId == -1 -> { strId = id; setStr(x) }
                }
            }
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) {
                val id = e.getPointerId(i)
                if (id == thrId) setThr(e.getY(i)) else if (id == strId) setStr(e.getX(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val id = e.getPointerId(e.actionIndex)
                if (id == thrId) { thrId = -1; thr = 0f }
                if (id == strId) { strId = -1; str = 0f }
            }
            MotionEvent.ACTION_CANCEL -> reset()
        }
        return true
    }

    private fun expo(x: Float, dead: Float): Float {
        val a = abs(x); if (a < dead) return 0f
        val n = (a - dead) / (1f - dead)
        val v = 0.4f * n + 0.6f * n * n * n
        return if (x < 0f) -v else v
    }

    private fun step() {
        val now = System.nanoTime(); val dt = min(0.05f, (now - last) / 1e9f); last = now
        t += dt; fdt = dt
        val cap = gearCap[gear]
        val tt = expo(thr, 0.06f) * cap * (if (invThr) -1f else 1f)
        val s = expo(str, 0.08f) * (if (invStr) -1f else 1f)
        var l: Float; var r: Float
        if (abs(tt) < 0.08f) { l = s * 0.85f * cap.coerceAtLeast(0.7f); r = -l }
        else {
            val steer = s * (0.6f + 0.4f * (1f - abs(tt)))
            l = tt + steer * abs(tt).coerceAtLeast(0.5f); r = tt - steer * abs(tt).coerceAtLeast(0.5f)
            val m = max(1f, max(abs(l), abs(r))); l /= m; r /= m
        }
        if (estop) { l = 0f; r = 0f }
        outL = (l * 100f).roundToInt(); outR = (r * 100f).roundToInt()
        val k = min(1f, dt * 14f)
        dispL += (l - dispL) * k; dispR += (r - dispR) * k
    }

    private fun steerBar(c: Canvas) {
        val r = strR; val cy = r.centerY(); val half = r.width() / 2f - 10 * d
        p.style = Paint.Style.FILL; p.shader = null; p.color = 0xCC0E1218.toInt(); c.drawRoundRect(r, 16 * d, 16 * d, p)
        val act = abs(str) > 0.02f
        g.glowRR(c, r, 16 * d, if (act) CYAN else LINE, 1.8f * d)
        val x = r.centerX() + str * half
        p.style = Paint.Style.FILL; p.color = CYAN; p.alpha = 120
        tmp.set(min(x, r.centerX()), r.top + 8 * d, max(x, r.centerX()), r.bottom - 8 * d); c.drawRect(tmp, p); p.alpha = 255
        p.color = LINE; c.drawRect(r.centerX() - d, r.top + 12 * d, r.centerX() + d, r.bottom - 12 * d, p)
        val dimC = g.mix(CYAN, BG, 0.5f)
        g.chevH(c, r.left + 18 * d, cy, -1, 9 * d, dimC); g.chevH(c, r.right - 18 * d, cy, 1, 9 * d, dimC)
        tmp.set(x - 14 * d, r.top + 4 * d, x + 14 * d, r.bottom - 4 * d)
        val tc = if (act) CYAN else TXT
        g.glowRR(c, tmp, 10 * d, tc, 2f * d)
        p.style = Paint.Style.FILL; p.color = tc; c.drawRoundRect(tmp, 10 * d, 10 * d, p)
    }

    private fun throttleBar(c: Canvas) {
        val r = thrR; val cy = r.centerY(); val half = r.height() / 2f - 10 * d
        p.style = Paint.Style.FILL; p.shader = null; p.color = 0xCC0E1218.toInt(); c.drawRoundRect(r, 16 * d, 16 * d, p)
        val act = abs(thr) > 0.02f
        g.glowRR(c, r, 16 * d, if (act) (if (thr > 0) ORG else CYAN) else LINE, 1.8f * d)
        val y = cy - thr * half
        tmp.set(r.left + 8 * d, min(y, cy), r.right - 8 * d, max(y, cy))
        p.style = Paint.Style.FILL; p.color = 0xFFFFFFFF.toInt(); p.shader = if (thr >= 0) fwd else rev; p.alpha = 215
        c.drawRect(tmp, p); p.shader = null; p.alpha = 255
        p.color = LINE; c.drawRect(r.left + 12 * d, cy - d, r.right - 12 * d, cy + d, p)
        g.chevV(c, r.centerX(), r.top + 20 * d, -1, 9 * d, g.mix(ORG, BG, 0.5f))
        g.chevV(c, r.centerX(), r.bottom - 20 * d, 1, 9 * d, g.mix(CYAN, BG, 0.5f))
        tmp.set(r.left + 4 * d, y - 14 * d, r.right - 4 * d, y + 14 * d)
        val tc = if (act) (if (thr > 0) g.mix(YEL, RED, thr) else CYAN) else TXT
        g.glowRR(c, tmp, 10 * d, tc, 2f * d)
        p.style = Paint.Style.FILL; p.color = tc; c.drawRoundRect(tmp, 10 * d, 10 * d, p)
        if (act && rnd() < abs(thr) * 0.9f) sp.emit(r.left + 6 * d, y, 1 + (abs(thr) * 2).toInt(), 340 * d, PIF, 1.4f, 2.2f * d)
    }

    private fun gauge(c: Canvas, v: Float, pw: Int) {
        val rect = RectF(gcx - gr, gcy - gr, gcx + gr, gcy + gr)
        p.style = Paint.Style.STROKE; p.shader = null; p.strokeCap = Paint.Cap.BUTT
        p.strokeWidth = gr * 0.13f; p.color = 0xFF1B212B.toInt(); c.drawArc(rect, 150f, 240f, false, p)
        for (i in 0..24) {
            val f = i / 24f; val a = (150f + 240f * f) * PIF / 180f
            val on = f <= v && v > 0.01f
            p.strokeWidth = (if (i % 4 == 0) 3.2f else 1.8f) * d
            p.color = if (on) g.mix(YEL, RED, f) else LINE
            c.drawLine(gcx + cos(a) * gr * 0.74f, gcy + sin(a) * gr * 0.74f, gcx + cos(a) * gr * 0.86f, gcy + sin(a) * gr * 0.86f, p)
        }
        val col = g.mix(AMBER, RED, v)
        if (v > 0.005f) { arc.reset(); arc.addArc(rect, 150f, 240f * v); g.glowPath(c, arc, col, gr * 0.10f) }
        val sz = gr * 0.62f
        if (pw > 0 && !estop) g.glowTxt(c, "$pw%", gcx, gcy - gr * 0.02f, sz, TXT, col)
        else g.txt(c, "$pw%", gcx, gcy - gr * 0.02f, sz, if (estop) RED else TXT)
        g.txt(c, if (estop) "E-STOP" else "ความเร่ง", gcx, gcy + gr * 0.50f, 10 * d, if (estop) RED else DIM, Paint.Align.CENTER, 0.1f)
        if (v > 0.02f) {
            val a = (150f + 240f * v) * PIF / 180f
            if (rnd() < 0.4f + v * 0.6f) sp.emit(gcx + cos(a) * gr, gcy + sin(a) * gr, 1 + (v * 3).toInt(), 320 * d * (0.5f + v), a, 1.3f, 2.4f * d)
        }
        // แท่งแรงล้อ (ไม่มีตัวอักษรบอกข้าง)
        for (side in 0..1) {
            val vv = if (side == 0) dispL else dispR
            val bx = gcx + (if (side == 0) -1 else 1) * gr * 1.22f
            tmp.set(bx - 5 * d, gcy - gr * 0.62f, bx + 5 * d, gcy + gr * 0.62f)
            p.style = Paint.Style.FILL; p.color = 0xCC151A21.toInt(); c.drawRoundRect(tmp, 5 * d, 5 * d, p)
            val mid = tmp.centerY(); val y = mid - vv * tmp.height() / 2f
            p.color = if (vv >= 0) ORG else CYAN; p.alpha = 230
            c.drawRect(tmp.left, min(y, mid), tmp.right, max(y, mid), p); p.alpha = 255
        }
    }

    override fun onDraw(c: Canvas) {
        val pw = (max(abs(dispL), abs(dispR)) * 100).roundToInt()
        val v = pw / 100f
        bd?.draw(c, t, v)
        steerBar(c); throttleBar(c); gauge(c, v, pw)
        for (i in 0..2) g.chip(c, gearR[i], gearName[i], if (i == 2) RED else if (i == 0) CYAN else AMBER, gear == i, 11 * d)
        g.chip(c, setupR, "SETUP", AMBER, false, 10 * d)
        g.chip(c, micR, "MIC", RED, false, 10 * d)
        g.chip(c, discR, "EXIT", DIM, false, 10 * d)
        // E-STOP
        p.style = Paint.Style.FILL; p.shader = null; p.color = if (estop) RED else 0xFF3A1210.toInt(); c.drawRoundRect(estopR, 14 * d, 14 * d, p)
        g.glowRR(c, estopR, 14 * d, RED, 1.8f * d)
        g.txt(c, if (estop) "RELEASE" else "E-STOP", estopR.centerX(), estopR.centerY(), 13 * d, if (estop) BG else RED)
        sp.draw(c, fdt, p, 300 * d)
        g.pill(c, pillR, online(), deviceName, t)
    }
}

// ============================================================ หน้าไมค์ (สั่งเสียง)
@SuppressLint("ViewConstructor")
class MicView(ctx: Context) : View(ctx) {
    var online: () -> Boolean = { false }
    var deviceName = ""
    @Volatile var listening = false
    @Volatile var level = 0f
    @Volatile var heard = ""
    private var cmdName = ""; private var cmdAt = 0L; private var cmdDur = 0L
    var onToggle: () -> Unit = {}
    var onBack: () -> Unit = {}
    var onStopCar: () -> Unit = {}
    fun flash(name: String, ms: Long) { cmdName = name; cmdAt = System.currentTimeMillis(); cmdDur = max(ms, 1200L) }

    private val d = resources.displayMetrics.density
    private val g = Gfx(d); private val p = g.p; private val sp = Sparks()
    private var bd: Backdrop? = null
    private var t = 0f; private var last = 0L; private var lv = 0f
    private val pillR = RectF(); private val backR = RectF(); private val stopR = RectF()
    private val rect = RectF(); private val circ = Path()
    private var mx = 0f; private var my = 0f; private var mr = 0f
    private val loop = object : Runnable { override fun run() { invalidate(); postOnAnimation(this) } }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); last = System.nanoTime(); postOnAnimation(loop) }
    override fun onDetachedFromWindow() { removeCallbacks(loop); super.onDetachedFromWindow() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        bd = Backdrop(w.toFloat(), h.toFloat(), d)
        val m = h * 0.06f
        pillR.set(m, m, m + 200 * d, m + 30 * d)
        backR.set(w - m - 90 * d, m, w - m, m + 32 * d)
        stopR.set(w - m - 110 * d, h - m - 40 * d, w - m, h - m)
        mx = w / 2f; my = h * 0.40f; mr = h * 0.15f
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            val x = e.x; val y = e.y
            when {
                backR.contains(x, y) -> onBack()
                stopR.contains(x, y) -> onStopCar()
                hypot(x - mx, y - my) < mr * 1.4f -> onToggle()
            }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val now = System.nanoTime(); val dt = min(0.05f, (now - last) / 1e9f); last = now; t += dt
        val on = listening
        lv += ((if (on) level else 0f) - lv) * min(1f, dt * 12f)
        bd?.draw(c, t, lv)
        // คลื่นเสียง
        val gap = (w / 2f - mr * 1.75f - 0.08f * w) / 14f
        p.style = Paint.Style.STROKE; p.shader = null; p.strokeCap = Paint.Cap.ROUND
        for (side in -1..1 step 2) for (i in 0 until 14) {
            val amp = if (on) (0.12f + lv * 0.88f) * (0.35f + 0.65f * abs(sin(i * 0.55f + t * 7f + side * 1.3f))) else 0.05f
            val hh = amp * h * 0.28f * (1f - i / 16f)
            val x = mx + side * (mr * 1.75f + i * gap)
            val col = g.mix(YEL, RED, i / 14f)
            p.color = col; p.strokeWidth = 8 * d; p.alpha = 40; c.drawLine(x, my - hh, x, my + hh, p)
            p.strokeWidth = 4 * d; p.alpha = 255; c.drawLine(x, my - hh, x, my + hh, p)
        }
        // วงแหวนพัลส์
        if (on) for (k in 0..2) {
            val ph = (t * 0.7f + k / 3f) % 1f
            p.color = ORG; p.alpha = ((1f - ph) * (110 + lv * 130)).toInt().coerceIn(0, 255); p.strokeWidth = 2.5f * d
            c.drawCircle(mx, my, mr * (1.1f + ph * (0.9f + lv)), p)
        }
        p.alpha = 255
        // ส่วนโค้งหมุน
        rect.set(mx - mr * 1.15f, my - mr * 1.15f, mx + mr * 1.15f, my + mr * 1.15f)
        p.strokeWidth = 4 * d; p.color = if (on) ORG else LINE
        for (k in 0..2) c.drawArc(rect, (t * (if (on) 160f else 30f) + k * 120f) % 360f, 62f, false, p)
        p.strokeCap = Paint.Cap.BUTT
        // วงกลมไมค์
        p.style = Paint.Style.FILL; p.color = g.mix(0xFF1A0A0A.toInt(), 0xFF8A1008.toInt(), lv); c.drawCircle(mx, my, mr, p)
        circ.reset(); circ.addCircle(mx, my, mr, Path.Direction.CW)
        g.glowPath(c, circ, if (on) ORG else DIM, 3f * d)
        // ไอคอนไมค์
        val ic = if (on) YEL else TXT
        p.style = Paint.Style.FILL; p.color = ic
        rect.set(mx - mr * 0.21f, my - mr * 0.55f, mx + mr * 0.21f, my + mr * 0.12f); c.drawRoundRect(rect, mr * 0.21f, mr * 0.21f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = mr * 0.07f; p.strokeCap = Paint.Cap.ROUND
        rect.set(mx - mr * 0.40f, my - mr * 0.28f, mx + mr * 0.40f, my + mr * 0.38f); c.drawArc(rect, 0f, 180f, false, p)
        c.drawLine(mx, my + mr * 0.38f, mx, my + mr * 0.56f, p)
        c.drawLine(mx - mr * 0.2f, my + mr * 0.56f, mx + mr * 0.2f, my + mr * 0.56f, p)
        p.strokeCap = Paint.Cap.BUTT
        if (on && lv > 0.25f && rnd() < lv) {
            val a = rnd() * 2f * PIF
            sp.emit(mx + cos(a) * mr, my + sin(a) * mr, 2, 380 * d, a, 0.6f, 2.4f * d)
        }
        // ข้อความ
        g.txt(c, if (on) "กำลังฟัง…" else "แตะไมค์เพื่อสั่งเสียง", mx, h * 0.665f, 13 * d, if (on) ORG else DIM)
        val tn = System.currentTimeMillis()
        if (tn - cmdAt < cmdDur) {
            g.glowTxt(c, cmdName, mx, h * 0.765f, 28 * d, YEL, ORG)
            val f = 1f - (tn - cmdAt).toFloat() / cmdDur
            p.style = Paint.Style.FILL; p.color = LINE; rect.set(mx - w * 0.15f, h * 0.83f, mx + w * 0.15f, h * 0.83f + 4 * d); c.drawRoundRect(rect, 2 * d, 2 * d, p)
            p.color = ORG; rect.set(mx - w * 0.15f, h * 0.83f, mx - w * 0.15f + w * 0.30f * f, h * 0.83f + 4 * d); c.drawRoundRect(rect, 2 * d, 2 * d, p)
        }
        g.txt(c, heard.take(40), mx, h * 0.88f, 14 * d, DIM)
        g.txt(c, "พูดว่า: เดินหน้า · ถอยหลัง · เลี้ยวซ้าย · เลี้ยวขวา · หยุด · เร็ว / ช้า", mx, h * 0.95f, 10.5f * d, 0xFF55606C.toInt())
        g.chip(c, backR, "BACK", AMBER, false, 11 * d)
        g.chip(c, stopR, "STOP CAR", RED, false, 11 * d)
        sp.draw(c, dt, p, 260 * d)
        g.pill(c, pillR, online(), deviceName, t)
    }
}

// ============================================================ แอปหลัก
class MainActivity : Activity() {
    private val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val ui = Handler(Looper.getMainLooper())
    private val q = LinkedBlockingQueue<String>()
    private var adapter: BluetoothAdapter? = null
    @Volatile private var sock: BluetoothSocket? = null
    @Volatile private var connected = false
    @Volatile private var session = 0
    @Volatile private var lastTele = 0L
    private var lastDev: BluetoothDevice? = null
    private var devName = "-"
    private var drive: DriveView? = null
    private var mic: MicView? = null
    private var home: HomeView? = null
    private var screen = 0            // 0 หน้าแรก, 1 ขับ, 2 ตั้งค่า, 3 ไมค์
    private val cfg = IntArray(12)
    private var afterPerm: (() -> Unit)? = null
    private var listBox: LinearLayout? = null
    private val found = LinkedHashMap<String, BluetoothDevice>()
    private var scanOn = false
    private var invBtn = arrayOfNulls<Button>(4)
    private var sideBtn = arrayOfNulls<Button>(4)
    private var trimL: SeekBar? = null; private var trimR: SeekBar? = null; private var rampBar: SeekBar? = null
    private var trimTxt: TextView? = null; private var rampTxt: TextView? = null; private var profBtn: Button? = null

    // สั่งเสียง
    private var sr: SpeechRecognizer? = null
    private var listening = false
    @Volatile private var voiceL = 0
    @Volatile private var voiceR = 0
    @Volatile private var voiceUntil = 0L
    private var voicePow = 60

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun send(s: String) { q.offer(s) }

    // ---------- UI helpers ----------
    private fun label(t: String, size: Float, color: Int = TXT, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

    private fun button(t: String, color: Int, fill: Boolean = false, click: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 13f; typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (fill) 0xFF1A0A00.toInt() else color)
        background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            if (fill) intArrayOf(AMBER, 0xFFFF4A00.toInt()) else intArrayOf(0xFF1B1F27.toInt(), 0xFF0E1116.toInt())).apply {
            cornerRadius = dp(12).toFloat(); setStroke(dp(2), if (fill) YEL else color)
        }
        stateListAnimator = null
        minHeight = dp(44); minimumHeight = dp(44)
        setOnClickListener { click() }
    }

    private fun page(content: View) {
        val sv = ScrollView(this).apply { setBackgroundColor(BG); addView(content) }
        setContentView(sv)
    }

    private fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        showDevices()
    }

    @Suppress("DEPRECATION")
    private fun immersive(on: Boolean) {
        window.decorView.systemUiVisibility = if (on) (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE) else View.SYSTEM_UI_FLAG_VISIBLE
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when (screen) { 1 -> disconnect(); 2 -> showDrive(); 3 -> { stopVoice(); showDrive() }; else -> super.onBackPressed() }
    }

    // ---------- หน้าแรก ----------
    private val receiver = object : BroadcastReceiver() {
        @Suppress("DEPRECATION")
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val d: BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33)
                        i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    else i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    if (d != null && !found.containsKey(d.address)) { found[d.address] = d; refreshList() }
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> scanOn = false
            }
        }
    }
    private var receiverOn = false

    private fun showDevices() {
        screen = 0; immersive(true); stopVoice()
        val dm = resources.displayMetrics
        val root = FrameLayout(this)
        val hv = HomeView(this).also { it.online = { connected }; home = it }
        root.addView(hv, FrameLayout.LayoutParams(-1, -1))
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), (dm.heightPixels * 0.12f).toInt() + dp(100), dp(6), dp(12))
        }
        val row = LinearLayout(this)
        row.addView(button("SCAN", AMBER, true) { ensurePermissions { startScan() } }, lp(0, dp(44), 1f))
        row.addView(button("RECONNECT", CYAN) { lastDev?.let { connect(it) } ?: toast("ยังไม่เคยเชื่อมต่อ") }, lp(0, dp(44), 1f))
        row.addView(button("🎤 MIC", RED) { if (connected) showMic() else toast("เชื่อมต่อรถก่อนนะ") }, lp(0, dp(44), 1f))
        col.addView(row)
        col.addView(label("จับคู่ THEP_4WD ใน Settings > Bluetooth ก่อน แล้วแตะชื่อด้านล่าง", 11f, DIM))
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sv = ScrollView(this).apply { addView(listBox) }
        col.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(col, FrameLayout.LayoutParams((dm.widthPixels * 0.46f).toInt(), -1))
        setContentView(root)
        ensurePermissions { loadBonded(); refreshList() }
    }

    @SuppressLint("MissingPermission")
    private fun loadBonded() {
        try { adapter?.bondedDevices?.forEach { found[it.address] = it } } catch (_: SecurityException) {}
    }

    @SuppressLint("MissingPermission")
    private fun refreshList() {
        val box = listBox ?: return
        box.removeAllViews()
        if (adapter?.isEnabled == false) { box.addView(label("Bluetooth ปิดอยู่ — เปิดก่อน", 14f, RED)); return }
        val list = found.values.sortedByDescending { isCar(it) }
        for (d in list) {
            val nm = try { d.name ?: d.address } catch (_: SecurityException) { d.address }
            box.addView(button((if (isCar(d)) "★ " else "") + nm + "\n" + d.address, if (isCar(d)) AMBER else DIM) { connect(d) }, lp(-1, dp(64)))
        }
        if (list.isEmpty()) box.addView(label("ไม่พบอุปกรณ์ — กด SCAN", 13f, DIM))
    }

    @SuppressLint("MissingPermission")
    private fun isCar(d: BluetoothDevice) = try { d.name?.contains("THEP", true) == true } catch (_: SecurityException) { false }

    @SuppressLint("MissingPermission")
    private fun startScan() {
        val a = adapter ?: return
        if (!receiverOn) {
            val f = IntentFilter(BluetoothDevice.ACTION_FOUND); f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            registerReceiver(receiver, f); receiverOn = true
        }
        try { if (a.isDiscovering) a.cancelDiscovery(); a.startDiscovery(); scanOn = true; toast("กำลังสแกน...") }
        catch (_: SecurityException) { toast("ไม่มีสิทธิ์ Bluetooth") }
    }

    @SuppressLint("MissingPermission")
    private fun stopScan() {
        try { if (scanOn) adapter?.cancelDiscovery() } catch (_: Exception) {}
        scanOn = false
        if (receiverOn) { try { unregisterReceiver(receiver) } catch (_: Exception) {}; receiverOn = false }
    }

    private fun ensurePermissions(then: () -> Unit) {
        val need = if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        val miss = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (miss.isEmpty()) then() else { afterPerm = then; requestPermissions(miss.toTypedArray(), 1) }
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<out String>, res: IntArray) {
        if (res.isNotEmpty() && res.all { it == PackageManager.PERMISSION_GRANTED }) afterPerm?.invoke()
        else toast(if (rc == 2) "ต้องอนุญาตไมค์ก่อนใช้สั่งเสียง" else "ต้องอนุญาต Bluetooth ก่อนใช้งาน")
        afterPerm = null
    }

    // ---------- การเชื่อมต่อ ----------
    @SuppressLint("MissingPermission")
    private fun openSocket(d: BluetoothDevice): BluetoothSocket {
        try {
            val s = d.createRfcommSocketToServiceRecord(SPP)
            try { s.connect(); return s } catch (_: Exception) { try { s.close() } catch (_: Exception) {} }
        } catch (_: Exception) {}
        val f = d.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType).invoke(d, 1) as BluetoothSocket
        f.connect(); return f
    }

    @SuppressLint("MissingPermission")
    private fun connect(d: BluetoothDevice) {
        stopScan()
        toast("กำลังเชื่อมต่อ...")
        val gen = ++session
        closeSock()
        Thread {
            var s: BluetoothSocket? = null
            var err: Exception? = null
            for (i in 0 until 2) {
                try { adapter?.cancelDiscovery(); s = openSocket(d); break } catch (e: Exception) { err = e; Thread.sleep(400) }
            }
            if (s == null || gen != session) {
                try { s?.close() } catch (_: Exception) {}
                ui.post { toast("เชื่อมต่อไม่สำเร็จ: ${err?.message ?: "ยกเลิก"}") }
                return@Thread
            }
            sock = s; q.clear(); connected = true; lastDev = d
            devName = try { d.name ?: d.address } catch (_: SecurityException) { d.address }
            startWriter(s, gen)
            ui.post { showDrive(); ui.removeCallbacks(tick); ui.post(tick); send("V"); send("G") }
            readLoop(s.inputStream, gen)
        }.start()
    }

    private fun startWriter(s: BluetoothSocket, gen: Int) {
        Thread {
            try {
                val os = s.outputStream
                while (connected && gen == session) {
                    val m = q.poll(200, TimeUnit.MILLISECONDS) ?: continue
                    os.write((m + "\n").toByteArray()); os.flush()
                }
            } catch (_: Exception) { lost(gen) }
        }.start()
    }

    private fun readLoop(input: InputStream, gen: Int) {
        val buf = ByteArray(256); val sb = StringBuilder()
        try {
            while (gen == session) {
                val n = input.read(buf); if (n < 0) break
                sb.append(String(buf, 0, n))
                while (true) {
                    val i = sb.indexOf("\n"); if (i < 0) break
                    val line = sb.substring(0, i).trim(); sb.delete(0, i + 1); handleLine(line)
                }
                if (sb.length > 512) sb.setLength(0)
            }
        } catch (_: Exception) {}
        lost(gen)
    }

    private fun handleLine(l: String) {
        when {
            l.startsWith("T,") -> { lastTele = System.currentTimeMillis() }
            l.startsWith("CFG,") -> {
                val p = l.substring(4).split(",")
                for (i in 0 until min(12, p.size)) cfg[i] = p[i].trim().toIntOrNull() ?: cfg[i]
                ui.post { refreshSetup() }
            }
            l.startsWith("FS") -> ui.post { toast("Failsafe: รถหยุดเอง (สัญญาณขาด)") }
        }
    }

    private fun lost(gen: Int) {
        if (gen != session || !connected) return
        connected = false; closeSock()
        ui.post { ui.removeCallbacks(tick); drive?.reset(); stopVoice(); toast("Bluetooth หลุด"); showDevices() }
    }

    private fun closeSock() { try { sock?.close() } catch (_: Exception) {}; sock = null }

    private fun disconnect() {
        ui.removeCallbacks(tick); drive?.reset(); stopVoice()
        send("S")
        val gen = session
        Thread { Thread.sleep(250); if (gen == session) { connected = false; session++; closeSock() } }.start()
        showDevices()
    }

    // ส่ง M 20 ครั้ง/วินาที (heartbeat) — หน้าขับใช้จอยสติ๊ก, หน้าไมค์ใช้คำสั่งเสียง (หมดเวลาแล้วหยุดเอง)
    private val tick = object : Runnable {
        override fun run() {
            if (!connected) return
            val dv = drive
            var l = 0; var r = 0
            if (screen == 1 && dv != null) { l = dv.outL; r = dv.outR }
            else if (screen == 3 && System.currentTimeMillis() < voiceUntil) { l = voiceL; r = voiceR }
            if (q.isEmpty()) send("M,$l,$r")
            dv?.linkOk = System.currentTimeMillis() - lastTele < 800
            ui.postDelayed(this, 50)
        }
    }

    // ---------- หน้าขับ ----------
    private fun showDrive() {
        screen = 1; immersive(true)
        val dv = drive ?: DriveView(this).also { drive = it }
        dv.deviceName = devName; dv.online = { connected }
        val pr = getSharedPreferences("thep", MODE_PRIVATE)
        dv.invThr = pr.getBoolean("invThr", false); dv.invStr = pr.getBoolean("invStr", false)
        dv.onSetup = { send("S"); showSetup() }
        dv.onMic = { showMic() }
        dv.onDisconnect = { disconnect() }
        dv.reset()
        (dv.parent as? android.view.ViewGroup)?.removeView(dv)
        setContentView(dv)
    }

    // ---------- หน้าไมค์ ----------
    private fun showMic() {
        screen = 3; immersive(true)
        voiceL = 0; voiceR = 0; voiceUntil = 0
        val mv = mic ?: MicView(this).also { mic = it }
        mv.deviceName = devName; mv.online = { connected }
        mv.listening = false; mv.heard = ""
        mv.onToggle = { if (listening) stopVoice() else startVoice() }
        mv.onBack = { stopVoice(); showDrive() }
        mv.onStopCar = { voiceUntil = 0; mic?.flash("หยุด", 0) }
        (mv.parent as? android.view.ViewGroup)?.removeView(mv)
        setContentView(mv)
    }

    private fun has(s: String, vararg w: String) = w.any { s.contains(it) }

    private fun startVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            afterPerm = { startVoice() }; requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { toast("เครื่องนี้ไม่มีระบบรู้จำเสียง (ต้องมี Google)"); return }
        listening = true; mic?.listening = true; listenOnce()
    }

    private fun stopVoice() {
        listening = false; mic?.listening = false; mic?.level = 0f
        voiceUntil = 0
        try { sr?.cancel(); sr?.destroy() } catch (_: Exception) {}
        sr = null
    }

    private fun listenOnce() {
        if (!listening || screen != 3) return
        try { sr?.destroy() } catch (_: Exception) {}
        val r = SpeechRecognizer.createSpeechRecognizer(this); sr = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) { mic?.level = ((v + 2f) / 12f).coerceIn(0f, 1f) }
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, b: Bundle?) {}
            override fun onError(e: Int) {
                if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { stopVoice(); toast("ไม่ได้รับสิทธิ์ไมค์"); return }
                ui.postDelayed({ if (sr === r) listenOnce() }, 350)
            }
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                if (t.isNotBlank()) handleVoice(t, true)
                ui.postDelayed({ if (sr === r) listenOnce() }, 150)
            }
            override fun onPartialResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                if (t.isNotBlank()) handleVoice(t, false)
            }
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "th-TH")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        })
    }

    private fun handleVoice(raw: String, final: Boolean) {
        val m = mic ?: return
        val s = raw.lowercase().replace(" ", "")
        m.heard = raw
        if (has(s, "หยุด", "จอด", "เบรก", "stop", "สตอป")) { voiceUntil = 0; m.flash("หยุด ■", 0); return }
        if (!final) return
        if (drive?.estop == true) { m.flash("E-STOP ล็อกอยู่", 0); return }
        val before = voicePow
        when {
            has(s, "เทอร์โบ", "เร็ว", "turbo") -> voicePow = 90
            has(s, "อีโค", "ช้า", "eco") -> voicePow = 35
            has(s, "ปกติ", "normal") -> voicePow = 60
        }
        val pw = voicePow
        fun go(n: String, l: Int, r: Int, ms: Long) { voiceL = l; voiceR = r; voiceUntil = System.currentTimeMillis() + ms; m.flash(n, ms) }
        when {
            has(s, "ถอย", "หลัง", "back") -> go("ถอยหลัง ▼", -pw, -pw, 1500)
            has(s, "ซ้าย", "left") -> go("เลี้ยว ◀", -pw * 8 / 10, pw * 8 / 10, 700)
            has(s, "ขวา", "right") -> go("เลี้ยว ▶", pw * 8 / 10, -pw * 8 / 10, 700)
            has(s, "หมุน", "spin") -> go("หมุน ⟳", pw, -pw, 2000)
            has(s, "หน้า", "ตรง", "วิ่ง", "ไป", "forward", "go") -> go("เดินหน้า ▲", pw, pw, 1500)
            voicePow != before -> m.flash("ความเร็ว $pw%", 0)
        }
    }

    // ---------- ตั้งค่า ----------
    private fun showSetup() {
        screen = 2; immersive(false)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(24)) }
        col.addView(button("◀ กลับไปขับ", AMBER, true) { showDrive() }, lp(-1, dp(48)))
        col.addView(label("ทิศทางการควบคุม (แก้เมื่อรถวิ่งสลับ)", 14f, AMBER, true))
        for ((key, name) in listOf("invThr" to "หน้า/ถอย", "invStr" to "ซ้าย/ขวา")) {
            val pr = getSharedPreferences("thep", MODE_PRIVATE)
            lateinit var b: Button
            fun txt() = "$name: " + if (pr.getBoolean(key, false)) "กลับด้าน" else "ปกติ"
            b = button(txt(), CYAN) { pr.edit().putBoolean(key, !pr.getBoolean(key, false)).apply(); b.text = txt() }
            col.addView(b, lp(-1, dp(48)))
        }
        col.addView(label("มอเตอร์ (ยกรถลอยล้อก่อนทดสอบ)", 14f, AMBER, true))
        for (m in 0..3) {
            val row = LinearLayout(this); row.gravity = Gravity.CENTER_VERTICAL
            row.addView(label("M${m + 1}", 16f, TXT, true), lp(dp(40), -2))
            row.addView(button("ทดสอบ", GREEN) { send("T,$m") }, lp(0, dp(46), 1f))
            sideBtn[m] = button("-", CYAN) { cfgMotor(m, flipSide = true) }.also { row.addView(it, lp(0, dp(46), 1f)) }
            invBtn[m] = button("-", AMBER) { cfgMotor(m, flipInv = true) }.also { row.addView(it, lp(0, dp(46), 1f)) }
            col.addView(row)
        }
        col.addView(label("ทดสอบ → ดูว่าล้อไหนหมุน แล้วกดข้าง (ซ้าย/ขวา) และทิศ (เดินหน้า/ถอย) ให้ตรง", 11f, DIM))

        col.addView(label("สมดุลแรง (ให้วิ่งตรง)", 14f, AMBER, true))
        trimTxt = label("", 12f, TXT); col.addView(trimTxt)
        trimL = seek(50, 100) { updTrim(); }.also { col.addView(it) }
        trimR = seek(50, 100) { updTrim(); }.also { col.addView(it) }
        col.addView(button("บันทึกสมดุล", GREEN) { send("K,${trimL!!.progress + 50},${trimR!!.progress + 50}") }, lp(-1, dp(46)))

        col.addView(label("กริป ⇄ แรงออกตัว", 14f, AMBER, true))
        rampTxt = label("", 12f, TXT); col.addView(rampTxt)
        rampBar = seek(3, 30) { rampTxt?.text = "ออกตัว: ${it + 3}  (ต่ำ = เกาะพื้น, สูง = พุ่งแรง)" }.also { col.addView(it) }
        col.addView(button("บันทึกการออกตัว", GREEN) { send("A,${rampBar!!.progress + 3}") }, lp(-1, dp(46)))

        profBtn = button("ผังสาย", CYAN) { confirmProfile() }; col.addView(profBtn, lp(-1, dp(48)))
        col.addView(button("รีเซ็ตมอเตอร์", RED) { send("X") }, lp(-1, dp(48)))
        page(col)
        refreshSetup(); send("G")
    }

    private fun seek(min: Int, max: Int, onChange: (Int) -> Unit) = SeekBar(this).apply {
        this.max = max - min
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { onChange(v + min) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    private fun updTrim() { trimTxt?.text = "ซ้าย ${(trimL?.progress ?: 0) + 50}%   ขวา ${(trimR?.progress ?: 0) + 50}%" }

    private fun cfgMotor(m: Int, flipSide: Boolean = false, flipInv: Boolean = false) {
        var s = cfg[4 + m]; var i = cfg[m]
        if (flipSide) s = 1 - s
        if (flipInv) i = 1 - i
        send("C,$m,$s,$i")
    }

    private fun refreshSetup() {
        if (screen != 2) return
        for (m in 0..3) {
            sideBtn[m]?.text = if (cfg[4 + m] == 1) "ข้าง: ขวา" else "ข้าง: ซ้าย"
            invBtn[m]?.text = if (cfg[m] == 1) "ทิศ: กลับ" else "ทิศ: ปกติ"
        }
        trimL?.progress = (cfg[8] - 50).coerceIn(0, 50); trimR?.progress = (cfg[9] - 50).coerceIn(0, 50)
        rampBar?.progress = (cfg[11] - 3).coerceIn(0, 27)
        profBtn?.text = "ผังสาย: ${if (cfg[10] == 1) "B (Fritzing)" else "A (เดิม)"}  — แตะเพื่อสลับ"
        updTrim()
    }

    private fun confirmProfile() {
        val to = 1 - cfg[10]
        AlertDialog.Builder(this).setMessage("สลับเป็นผังสาย ${if (to == 1) "B" else "A"} แล้วรีสตาร์ท ESP32 (บลูทูธจะหลุด)")
            .setPositiveButton("ตกลง") { _, _ -> send("P,$to") }.setNegativeButton("ยกเลิก", null).show()
    }

    // ---------- ความปลอดภัย ----------
    override fun onPause() {
        super.onPause()
        drive?.reset(); stopVoice()
        if (connected) send("S")
    }

    override fun onDestroy() {
        stopScan(); ui.removeCallbacks(tick); stopVoice()
        if (connected) { send("S"); Thread.sleep(80) }
        session++; connected = false; closeSock()
        super.onDestroy()
    }
}
